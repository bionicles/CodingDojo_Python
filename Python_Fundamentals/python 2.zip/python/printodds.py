maximum = 1000

for i in range (0, maximum):
	if i % 2 == 0:
		continue
	else:
		print i



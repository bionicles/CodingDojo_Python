maximum = 1000000

for i in range (0, maximum):
	if i % 5 == 0:
		print i
	else:
		continue


